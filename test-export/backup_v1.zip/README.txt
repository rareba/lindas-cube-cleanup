LINDAS Cube Backup
==================

Cube: https://energy.ld.admin.ch/sfoe/bfe_ogd18_gebaeudeprogramm_co2wirkung/1
Version: 1
Graph: https://energy.ld.admin.ch/sfoe/cube
Created: 2026-01-20T14:44:06.347Z
Triples: 1046

Files in this archive:
- manifest.json: Complete metadata and restore instructions
- data.nt: The actual RDF triples in N-Triples format
- README.txt: This file

To restore this backup:
1. Use the LINDAS Cube Manager "Import Backup" function
2. Or manually POST data.nt to your triplestore's data endpoint

Source Triplestore: graphdb
Source Endpoint: http://localhost:7200
Source Dataset: lindas
